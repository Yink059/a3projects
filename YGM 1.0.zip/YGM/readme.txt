﻿//////////////////////////////////////////////////////////////////////////////////////

By: |TG-355th| Yink

Tactical Gamer - The PREMIERE community for mature gamers

//////////////////////////////////////////////////////////////////////////////////////

Yink's Group Manager	(YGM)

v 1.0

//////////////////////////////////////////////////////////////////////////////////////

Contact:

yinkf@aol.com - if you have any mission dev questions

//////////////////////////////////////////////////////////////////////////////////////

Features:

•	manage groups on the fly
•	rename them
•	kick/invite members
•	works for all 4 factions
•	admin compatible

//////////////////////////////////////////////////////////////////////////////////////

Usage:

1.	copy YGM folder into main mission directory (where the init.sqf is)

2.	based on game mode, put one of these lines in the init.sqf:

PvP:
execVM "YGM\Inits\initYGMpvp.sqf"; //PVP will put all members into one big group


Coop:
execVM "YGM\Inits\initYGMcoop.sqf";	//COOP will put only kicked members into large group

3. put this line in the description.ext

#include "YGM\Dialogs\YinkGmDefines.hpp"

4. press Teamswitch key ingame to access manager (default "U")

//////////////////////////////////////////////////////////////////////////////////////


Download:


YGM 1.0

Repository

//////////////////////////////////////////////////////////////////////////////////////

Todo: 

• make activation key dynamic. currently its locked to T because of some scripting limitations i had earlier, but i ended not using that feature but stuck with the static bind anyways. in the next release it will be bound to the users teamswitch key. done, saved as 1.0. changed 1 line in the script

•